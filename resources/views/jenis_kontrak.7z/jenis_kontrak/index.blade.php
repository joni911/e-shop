@extends('adminlte::page')

@section('title', 'Jenis Kontrak')

@section('content_header')



@stop

@section('content')

<body>
    @include('jenis_kontrak.part.table')
</body>

@stop

@section('css')

@stop

@section('js')

@stop
